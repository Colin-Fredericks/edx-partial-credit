// We use HTML5 Web Storage to keep an out-of-date version of the grades.
// This pre-populates the skill tree. It's just a visual nicety.
function getTreeFromLocalStorage() {
	
	// Make sure we have local storage.
	if(typeof(Storage) !== 'undefined') {
		
		var partNames = [];
		var partScores = [];
		var partTypes = [];
		
		// Store the grade details as JSON
		if(typeof localStorage.partNames !== 'undefined'){
			partNames = JSON.parse(localStorage.partNames);
			partScores = JSON.parse(localStorage.partScores);
			partTypes = JSON.parse(localStorage.partTypes);
		}
		
		// Log the details and call displayTree
		console.log(partNames, partScores, partTypes);
		displayTree(partNames, partScores, partTypes);

	}else{
		console.log('No local storage');
	}

}

// If we're going to use HTML5 Web Storage, we need to store things in it.
function storeTreeToLocalStorage(partNames, partScores, partTypes){
	
	// Make sure we have local storage.
	if(typeof(Storage) !== "undefined") {
		
		// Don't bother to coerce data types.
		// Javascript will treat strings like numbers anyway with ==.
		localStorage.partNames = JSON.stringify(partNames);
		localStorage.partScores = JSON.stringify(partScores);
		localStorage.partTypes = JSON.stringify(partTypes);
		
	}else{
		console.log('No local storage');
	}

}


// This goes through the Progress Page (loaded in the Raw HTML component), finds
// all of the grades, stores them in HTML5 local storage, and calls displayTree.
function updateTreeFromProgPage(){
	console.log('grade frame ready');

	var progpage = $('#yourprogress');
	var allParts = progpage.contents().find('h3 a'); // This will need to be updated if the Progress page changes.

	var partNames = [];
	var partScores = [];
	var partTypes = [];
	var tempName;
	var tempPart;
	var tempType;
	
	// This section is perhaps the most fragile. If the Progress page changes,
	// almost everything in this each() function will need to be updated.
	allParts.each(function(index, e){
		tempName = $(e).text().trim().split('\n')[0];
		partNames[index] = tempName;
		
		tempPart = progpage.contents().find('h3 a:contains("'+tempName+'")').next().text();
		partScores[index] = tempPart.slice(tempPart.length - 4, tempPart.length - 1);
		
		tempType = progpage.contents().find('h3 a:contains("'+tempName+'")').parent().next().text();
		partTypes[index] = tempType.trim();
	});


	// Replace spaces with underscores in the subsection names. HTML id's don't like spaces.
	for(var i=0; i < partNames.length; i++){
		partNames[i] = partNames[i].replace(' ','_');
	}
	
	// Turn off the loading bar.
	$('#progressbar').progressbar('destroy');
	
	// Track progress, store in Web Storage, and display the tree.
	console.log(partNames, partScores, partTypes);
	storeTreeToLocalStorage(partNames, partScores, partTypes);
	displayTree(partNames, partScores, partTypes);

}


// Shows which parts of the course have been completed according to student grades.
// The tree itself is created in the Raw HTML component.
function displayTree(partNames, partScores, partTypes){

	// typesWeLike and gradeCutoff are global variables from the HTML component.
	// This section gets the scores for the subsections with the types we care about,
	// and displays those elements whose classes correspond with the ones people passed.

	for(var i=0; i < typesWeLike.length; i++){
		console.log(typesWeLike[i]);
		for(var j=0; j < partTypes.length; j++){
			if(partTypes[j] == typesWeLike[i]){
				if(partScores[j] >= gradeCutoff){
 					$( '.' + partNames[j] +'.incomplete' ).css('display','none');
 					$( '.' + partNames[j] +'.complete' ).css('display','initial'); 
 					console.log( partNames[j] + ' marked complete' );
				}else{
					$( '.' + partNames[j] +'.complete' ).css('display','none'); 
					$( '.' + partNames[j] +'.incomplete' ).css('display','initial'); 
					console.log( partNames[j] + ' marked incomplete' );
				}
			}
		}
	}
}

